package com.kartali.pagos

import org.json.JSONObject

/**
 * Representa una orden de pago enviada desde Telegram / Google Apps Script.
 */
data class PaymentOrder(
    val id: String,
    val tipo: String,         // "pagomovil", "terceros", "otrosbancos"
    val banco: String,        // Código de 4 dígitos ej: "0102", "0134"
    val cedula: String,       // Ej: "V12345678"
    val telefono: String,     // Ej: "04141234567"
    val cuenta: String,       // Cuenta de 20 dígitos si es transferencia
    val monto: String,        // Monto en Bs ej: "1545.20"
    val dolares: String,      // Monto en $ ej: "50"
    val metodo: String,       // "cash", "zelle", "paypal", "zinli"
    val cliente: String,      // Nombre del cliente ej: "Samuel Lopez"
    val timestamp: Long = System.currentTimeMillis()
) {
    companion object {
        fun fromJson(json: JSONObject): PaymentOrder {
            return PaymentOrder(
                id = json.optString("id", System.currentTimeMillis().toString()),
                tipo = json.optString("tipo", "pagomovil"),
                banco = json.optString("banco", ""),
                cedula = json.optString("cedula", ""),
                telefono = json.optString("telefono", ""),
                cuenta = json.optString("cuenta", ""),
                monto = json.optString("monto", "0"),
                dolares = json.optString("dolares", "0"),
                metodo = json.optString("metodo", "cash"),
                cliente = json.optString("cliente", "Cliente")
            )
        }
    }

    /**
     * Texto formateado para el portapapeles según el tipo de pago de BDV.
     */
    fun toBdvClipboardText(): String {
        return when (tipo.lowercase()) {
            "pagomovil" -> "$banco\n$cedula\n$telefono\n$monto"
            "terceros" -> "$cuenta\n$cedula\n$monto"
            "otrosbancos" -> "$banco\n$cuenta\n$cedula\n$monto"
            else -> "$banco\n$cedula\n$telefono\n$monto"
        }
    }

    /**
     * Línea para anexar a la lista de "Pendientes por recibir:" en Compra y Venta.
     */
    fun toGroupListRow(): String {
        return "${dolares}$ ${metodo.lowercase()} $cliente"
    }
}
