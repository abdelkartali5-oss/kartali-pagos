package com.kartali.pagos

import android.content.Context
import android.content.Intent
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

/**
 * Motor central de automatización de Kartali Pagos.
 * Ejecuta paso a paso la secuencia en BDVApp y WhatsApp con tiempos humanos deliberados.
 */
class AutomationEngine(private val context: Context) {

    companion object {
        private const val TAG = "KartaliEngine"
        private const val BDV_PACKAGE = "com.bancodevenezuela.bdvdigital"
        private const val WHATSAPP_PACKAGE = "com.whatsapp"
    }

    interface Logger {
        fun log(message: String)
    }

    var logger: Logger? = null

    private fun log(msg: String) {
        Log.i(TAG, msg)
        logger?.log(msg)
    }

    suspend fun executePayment(order: PaymentOrder): Boolean = withContext(Dispatchers.Default) {
        val service = KartaliAccessibilityService.instance
        if (service == null) {
            log("❌ Error: Servicio de Accesibilidad no está activo.")
            return@withContext false
        }

        val storage = SecurityStorage(context)
        val password = storage.getPassword()
        if (password.isNullOrEmpty()) {
            log("❌ Error: No hay contraseña de BDV guardada en la aplicación.")
            return@withContext false
        }

        try {
            log("🚀 Iniciando orden #${order.id} | ${order.dolares}$ ${order.metodo} a ${order.cliente}")

            // 1. Abrir Banco de Venezuela
            log("📲 Abriendo Banco de Venezuela...")
            val launchIntent = context.packageManager.getLaunchIntentForPackage(BDV_PACKAGE)
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                context.startActivity(launchIntent)
            } else {
                log("❌ Error: No se encontró la aplicación BDV instalada.")
                return@withContext false
            }

            // Pausa para carga inicial de la pantalla de bienvenida
            delay(3500)

            // 2. Clic en "Iniciar sesión"
            log("👆 Tocando 'Iniciar sesión'...")
            service.clickByText("Iniciar sesión")
            delay(2000)

            // 3. Cancelar la huella digital de Samsung
            log("🔙 Pulsando botón Atrás para descartar huella...")
            service.pressBack()
            delay(1500)

            // 4. Clic en "Ingresa con tu contraseña"
            log("👆 Tocando 'Ingresa con tu contraseña'...")
            service.clickByText("Ingresa con tu contraseña")
            delay(2000)

            // 5. Clic exacto en la cajita de la clave (X: 45%, Y: 48.5%)
            log("🎯 Tocando directamente la casilla de contraseña (coordenada exacta)...")
            service.clickAtPercent(0.45f, 0.485f)
            delay(800)

            // 6. Pegar la contraseña
            log("🔐 Pegando contraseña guardada...")
            service.setClipboard(password)
            val pasted = service.pasteIntoActiveField()
            if (!pasted) {
                // Fallback: inyección de texto si paste no engancha
                service.setTextIntoActiveField(password)
            }
            delay(1200)

            // 7. Clic en "Aceptar" (X: 41.2%, Y: 56.7% o por texto)
            log("👆 Tocando 'Aceptar' para entrar al banco...")
            if (!service.clickByText("Aceptar", exact = true)) {
                service.clickAtPercent(0.412f, 0.567f)
            }

            // Pausa crucial para validación en servidor BDV y carga del menú principal
            log("⏳ Esperando carga del menú principal (4 segundos)...")
            delay(4000)

            // 8. Cargar datos del cliente al Portapapeles (después del login para evitar sobrescrituras)
            val bdvClipboardData = order.toBdvClipboardText()
            service.setClipboard(bdvClipboardData)
            log("📋 Datos del pago cargados al portapapeles:\n$bdvClipboardData")
            delay(500)

            // 9. Bifurcación inteligente según el tipo de pago
            when (order.tipo.lowercase()) {
                "pagomovil" -> {
                    log("📍 Ejecutando ruta: Pago Móvil...")
                    service.clickByText("Pagos")
                    delay(2000)
                    service.clickByText("PagomóvilBDV")
                    delay(2500)
                }
                "terceros" -> {
                    log("📍 Ejecutando ruta: Transferencia a Terceros BDV (0102)...")
                    service.clickByText("Transfer")
                    delay(2000)
                    service.clickByText("Cuentas de terceros")
                    delay(2500)
                }
                "otrosbancos" -> {
                    log("📍 Ejecutando ruta: Transferencia a Otros Bancos...")
                    service.clickByText("Transfer")
                    delay(2000)
                    service.clickByText("Cuentas otros bancos")
                    delay(2500)
                }
                else -> {
                    log("📍 Tipo no especificado, asumiendo Pago Móvil...")
                    service.clickByText("Pagos")
                    delay(2000)
                    service.clickByText("PagomóvilBDV")
                    delay(2500)
                }
            }

            // 10. Tocar "Pegar datos"
            log("📌 Tocando 'Pegar datos'...")
            service.clickByText("Pegar datos")
            delay(2000)

            // 11. Tocar "Pagar"
            log("💳 Tocando 'Pagar'...")
            service.clickByText("Pagar")
            delay(4000)

            log("✅ ¡Pago emitido en BDV! Esperando pantalla de comprobante...")
            delay(2000)

            // 12. Flujo de WhatsApp: Compartir comprobante y actualizar lista
            executeWhatsAppSharing(service, order)

            log("🏁 ¡Operación #${order.id} completada exitosamente!")
            return@withContext true

        } catch (e: Exception) {
            log("❌ Excepción durante la automatización: ${e.message}")
            e.printStackTrace()
            return@withContext false
        }
    }

    /**
     * Módulo de compartir comprobante y actualización de la lista en WhatsApp.
     */
    private suspend fun executeWhatsAppSharing(service: KartaliAccessibilityService, order: PaymentOrder) {
        log("📤 Iniciando compartición de comprobante a WhatsApp...")

        // 1. Tocar icono de Compartir en el recibo (arriba a la derecha)
        val shareClicked = service.clickByText("Compartir") || service.clickAtPercent(0.90f, 0.07f)
        delay(2500)

        // 2. Seleccionar WhatsApp en el menú de compartir
        log("📲 Seleccionando WhatsApp...")
        service.clickByText("WhatsApp")
        delay(2500)

        // 3. Seleccionar grupo "Compra y venta"
        log("👥 Buscando grupo 'Compra y venta'...")
        service.clickByText("Compra y venta")
        delay(1500)

        // Tocar botón verde de siguiente/enviar
        service.clickByText("Siguiente") || service.clickAtPercent(0.90f, 0.93f)
        delay(2000)

        // 4. Agregar comentario con el monto en dólares (ej: 50$)
        log("✍️ Escribiendo comentario: ${order.dolares}$...")
        service.clickByText("Añade un comentario")
        delay(500)
        service.setTextIntoActiveField("${order.dolares}$")
        delay(800)

        // 5. Enviar comprobante
        log("🚀 Enviando comprobante con foto al grupo...")
        service.clickAtPercent(0.90f, 0.93f) // Botón de enviar en WhatsApp
        delay(3000)

        // 6. Actualizar la lista consolidada de "Pendientes por recibir:"
        log("📋 Actualizando lista consolidada en el grupo...")
        updateConsolidatedList(service, order)
    }

    /**
     * Copia la última lista 'Pendientes por recibir:', agrega la nueva línea y la envía.
     */
    private suspend fun updateConsolidatedList(service: KartaliAccessibilityService, order: PaymentOrder) {
        val texts = service.getAllScreenTexts()
        val listMessage = texts.lastOrNull { it.contains("Pendientes por recibir:", ignoreCase = true) }

        if (listMessage != null && listMessage.startsWith("Pendientes por recibir:", ignoreCase = true)) {
            val updatedList = "$listMessage\n${order.toGroupListRow()}"
            log("📝 Lista actualizada con nueva fila: ${order.toGroupListRow()}")

            // Tocar barra de escribir mensaje
            service.clickByText("Mensaje")
            delay(500)
            service.setTextIntoActiveField(updatedList)
            delay(1000)

            // Enviar mensaje
            service.clickAtPercent(0.90f, 0.93f)
            delay(1500)
            log("✅ Lista actualizada enviada al grupo 'Compra y venta'.")
        } else {
            log("⚠️ Alerta de Seguridad: No se encontró la lista 'Pendientes por recibir:' en pantalla. No se sobrescribió para evitar dañar datos.")
        }

        // Regresar a Home
        service.goHome()
    }
}
