package com.kartali.pagos

import android.os.Handler
import android.os.Looper
import android.util.Log
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Registro central: lo escriben el servicio y el motor, lo muestra la pantalla principal. */
object AppLog {
    private val lines = mutableListOf<String>()
    private val main = Handler(Looper.getMainLooper())

    @Volatile
    var listener: ((String) -> Unit)? = null

    fun log(msg: String) {
        val t = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        val line = "[$t] $msg"
        Log.i("Kartali", line)
        synchronized(lines) {
            lines.add(line)
            while (lines.size > 300) lines.removeAt(0)
        }
        main.post { listener?.invoke(line) }
    }

    fun all(): String = synchronized(lines) { lines.joinToString("\n") }

    fun clear() = synchronized(lines) { lines.clear() }
}
