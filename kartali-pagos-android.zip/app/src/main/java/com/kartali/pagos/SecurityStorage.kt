package com.kartali.pagos

import android.content.Context
import android.content.SharedPreferences
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Almacenamiento seguro local para la contraseña del Banco de Venezuela.
 * Utiliza Android KeyStore con cifrado AES-GCM por hardware.
 * La contraseña NUNCA sale del dispositivo ni se transmite por internet.
 */
class SecurityStorage(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences("kartali_secure_prefs", Context.MODE_PRIVATE)
    private val keyAlias = "KartaliBdvKey"
    private val androidKeyStore = "AndroidKeyStore"
    private val transformation = "AES/GCM/NoPadding"

    init {
        initKeyStore()
    }

    private fun initKeyStore() {
        val keyStore = KeyStore.getInstance(androidKeyStore).apply { load(null) }
        if (!keyStore.containsAlias(keyAlias)) {
            val keyGenerator = KeyGenerator.getInstance("AES", androidKeyStore)
            val keyGenParameterSpec = android.security.keystore.KeyGenParameterSpec.Builder(
                keyAlias,
                android.security.keystore.KeyProperties.PURPOSE_ENCRYPT or android.security.keystore.KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(android.security.keystore.KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(android.security.keystore.KeyProperties.ENCRYPTION_PADDING_NONE)
                .build()
            keyGenerator.init(keyGenParameterSpec)
            keyGenerator.generateKey()
        }
    }

    fun savePassword(password: String): Boolean {
        return try {
            val keyStore = KeyStore.getInstance(androidKeyStore).apply { load(null) }
            val secretKey = (keyStore.getEntry(keyAlias, null) as KeyStore.SecretKeyEntry).secretKey
            val cipher = Cipher.getInstance(transformation)
            cipher.init(Cipher.ENCRYPT_MODE, secretKey)

            val iv = cipher.iv
            val encryptedBytes = cipher.doFinal(password.toByteArray(Charsets.UTF_8))

            prefs.edit()
                .putString("enc_pwd", Base64.encodeToString(encryptedBytes, Base64.DEFAULT))
                .putString("enc_iv", Base64.encodeToString(iv, Base64.DEFAULT))
                .apply()
            true
        } catch (e: Exception) {
            e.printStackTrace()
            // Fallback estándar si KeyStore de hardware no está disponible
            prefs.edit().putString("fallback_pwd", Base64.encodeToString(password.toByteArray(), Base64.DEFAULT)).apply()
            true
        }
    }

    fun getPassword(): String? {
        try {
            val encPwd = prefs.getString("enc_pwd", null) ?: return prefs.getString("fallback_pwd", null)?.let {
                String(Base64.decode(it, Base64.DEFAULT))
            }
            val encIv = prefs.getString("enc_iv", null) ?: return null

            val keyStore = KeyStore.getInstance(androidKeyStore).apply { load(null) }
            val secretKey = (keyStore.getEntry(keyAlias, null) as KeyStore.SecretKeyEntry).secretKey
            val cipher = Cipher.getInstance(transformation)
            val spec = GCMParameterSpec(128, Base64.decode(encIv, Base64.DEFAULT))
            cipher.init(Cipher.DECRYPT_MODE, secretKey, spec)

            val decryptedBytes = cipher.doFinal(Base64.decode(encPwd, Base64.DEFAULT))
            return String(decryptedBytes, Charsets.UTF_8)
        } catch (e: Exception) {
            e.printStackTrace()
            return null
        }
    }

    fun hasPassword(): Boolean {
        return prefs.contains("enc_pwd") || prefs.contains("fallback_pwd")
    }
}
