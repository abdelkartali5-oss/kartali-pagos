package com.kartali.pagos

import android.content.Context
import android.content.Intent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

/**
 * Motor central de automatización de Kartali Pagos.
 * Ejecuta paso a paso la secuencia en BDVApp y WhatsApp con tiempos humanos deliberados (2.5 a 4 s).
 */
class AutomationEngine(private val context: Context) {

    companion object {
        private const val BDV_PACKAGE = "com.bancodevenezuela.bdvdigital"
    }

    private fun log(msg: String) {
        AppLog.log(msg)
    }

    suspend fun executePayment(order: PaymentOrder): Boolean = withContext(Dispatchers.Default) {
        val service = KartaliAccessibilityService.instance
        if (service == null) {
            log("❌ Error: Servicio de Accesibilidad no está activo.")
            return@withContext false
        }

        val storage = SecurityStorage(context)
        val password = storage.getPassword()
        if (password.isNullOrEmpty()) {
            log("❌ Error: No hay contraseña de BDV guardada en la aplicación.")
            return@withContext false
        }

        try {
            log("🚀 Iniciando orden #${order.id} | ${order.dolares}$ ${order.metodo} a ${order.cliente}")

            // Despertar pantalla
            try {
                val wakeIntent = Intent(service, WakeActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                service.startActivity(wakeIntent)
            } catch (_: Exception) {}
            delay(1000)

            // 1. Abrir Banco de Venezuela usando el contexto del AccessibilityService
            // (los AccessibilityServices tienen permiso de Android 14 para lanzar actividades desde segundo plano)
            log("📲 Abriendo Banco de Venezuela...")
            val pm = service.packageManager
            var launchIntent = pm.getLaunchIntentForPackage(BDV_PACKAGE)
            if (launchIntent == null) {
                // Fallback buscando en todos los paquetes instalables con launcher
                val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
                    addCategory(Intent.CATEGORY_LAUNCHER)
                }
                val apps = pm.queryIntentActivities(mainIntent, 0)
                val bdvApp = apps.firstOrNull {
                    it.activityInfo.packageName.contains("bancodevenezuela", ignoreCase = true) ||
                    it.activityInfo.packageName.contains("bdv", ignoreCase = true)
                }
                if (bdvApp != null) {
                    launchIntent = pm.getLaunchIntentForPackage(bdvApp.activityInfo.packageName)
                }
            }

            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                service.startActivity(launchIntent)
            } else {
                log("❌ Error: No se encontró la aplicación BDV instalada.")
                return@withContext false
            }

            // Pausa humana para carga inicial de la pantalla de bienvenida
            delay(4000)

            // 2. Clic en "Iniciar sesión"
            log("👆 Tocando 'Iniciar sesión'...")
            if (!service.clickByText("Iniciar sesión")) {
                service.clickAtPercent(0.50f, 0.50f)
            }
            delay(2500)

            // 3. Cancelar la huella digital de Samsung con botón Atrás
            log("🔙 Pulsando botón Atrás para descartar huella...")
            service.pressBack()
            delay(2000)

            // 4. Clic en "Ingresa con tu contraseña"
            log("👆 Tocando 'Ingresa con tu contraseña'...")
            service.clickByText("Ingresa con tu contraseña")
            delay(2500)

            // 5. Clic exacto en la cajita de la clave (X: 45%, Y: 48.5%)
            log("🎯 Tocando directamente la casilla de contraseña...")
            service.clickAtPercent(0.45f, 0.485f)
            delay(1500)

            // 6. Pegar la contraseña
            log("🔐 Escribiendo contraseña guardada...")
            service.setClipboard(password)
            delay(300)
            val injected = service.setTextIntoActiveField(password)
            if (!injected) {
                service.pasteIntoActiveField()
            }
            delay(2000)

            // 7. Clic en "Aceptar" (X: 41.2%, Y: 56.7% o por texto)
            log("👆 Tocando 'Aceptar' para entrar al banco...")
            if (!service.clickByText("Aceptar", exact = true)) {
                service.clickAtPercent(0.412f, 0.567f)
            }

            // Pausa crucial para validación en servidor BDV y carga del menú principal
            log("⏳ Esperando carga del menú principal (4.5 segundos)...")
            delay(4500)

            // 8. Cargar datos del cliente al Portapapeles (después del login para evitar sobrescrituras)
            val bdvClipboardData = order.toBdvClipboardText()
            service.setClipboard(bdvClipboardData)
            log("📋 Datos del pago listos en portapapeles.")
            delay(1500)

            // 9. Bifurcación inteligente según el tipo de pago
            when (order.tipo.lowercase()) {
                "pagomovil" -> {
                    log("📍 Ruta: Pago Móvil...")
                    service.clickByText("Pagos")
                    delay(3000)
                    service.clickByText("PagomóvilBDV")
                    delay(3000)
                }
                "terceros" -> {
                    log("📍 Ruta: Transferencia a Terceros BDV (0102)...")
                    service.clickByText("Transfer")
                    delay(3000)
                    service.clickByText("Cuentas de terceros")
                    delay(3000)
                }
                "otrosbancos" -> {
                    log("📍 Ruta: Transferencia a Otros Bancos...")
                    service.clickByText("Transfer")
                    delay(3000)
                    service.clickByText("Cuentas otros bancos")
                    delay(3000)
                }
                else -> {
                    log("📍 Ruta por defecto: Pago Móvil...")
                    service.clickByText("Pagos")
                    delay(3000)
                    service.clickByText("PagomóvilBDV")
                    delay(3000)
                }
            }

            // 10. Tocar "Pegar datos"
            log("📌 Tocando 'Pegar datos'...")
            service.clickByText("Pegar datos")
            delay(3000)

            // 11. Tocar "Pagar" / "Transferir"
            log("💳 Tocando 'Pagar'...")
            if (!service.clickByText("Pagar")) {
                service.clickByText("Transferir")
            }
            delay(5000)

            log("✅ Pago emitido en BDV. Procesando comprobante...")
            delay(2500)

            // 12. Flujo de WhatsApp: Compartir al cliente, al grupo y actualizar lista
            executeWhatsAppSharing(service, order)

            log("🏁 ¡Operación #${order.id} completada exitosamente!")
            return@withContext true

        } catch (e: Exception) {
            log("❌ Excepción durante la automatización: ${e.message}")
            e.printStackTrace()
            return@withContext false
        }
    }

    /**
     * Comparte el comprobante en WhatsApp (grupo Compra y venta + cliente) y actualiza la lista.
     */
    private suspend fun executeWhatsAppSharing(service: KartaliAccessibilityService, order: PaymentOrder) {
        log("📤 Tocando icono Compartir en el comprobante...")

        // 1. Tocar icono de Compartir en el recibo (arriba a la derecha)
        if (!service.clickByText("Compartir")) {
            service.clickAtPercent(0.90f, 0.07f)
        }
        delay(3000)

        // 2. Seleccionar WhatsApp en el menú de compartir
        log("📲 Abriendo WhatsApp...")
        service.clickByText("WhatsApp")
        delay(3000)

        // 3. Seleccionar grupo "Compra y venta" (y al cliente si aparece en recientes)
        log("👥 Seleccionando 'Compra y venta'...")
        service.clickByText("Compra y venta")
        delay(2000)
        if (order.cliente.isNotBlank() && !order.cliente.equals("Cliente", ignoreCase = true)) {
            service.clickByText(order.cliente)
            delay(1500)
        }

        // Tocar botón verde de siguiente/enviar en selector de contactos
        if (!service.clickByText("Siguiente")) {
            service.clickAtPercent(0.90f, 0.93f)
        }
        delay(2500)

        // 4. Agregar comentario con el monto en dólares (ej: 50$)
        log("✍️ Escribiendo monto: ${order.dolares}$...")
        service.setClipboard("${order.dolares}$")
        service.clickByText("Añade un comentario")
        delay(1000)
        if (!service.setTextIntoActiveField("${order.dolares}$")) {
            service.pasteIntoActiveField()
        }
        delay(2000)

        // 5. Enviar comprobante
        log("🚀 Enviando comprobante a WhatsApp...")
        service.clickAtPercent(0.90f, 0.93f)
        delay(3500)

        // 6. Actualizar la lista consolidada de "Pendientes por recibir:"
        log("📋 Actualizando lista 'Pendientes por recibir:'...")
        updateConsolidatedList(service, order)
    }

    /**
     * Copia la última lista 'Pendientes por recibir:', agrega la nueva línea y la envía.
     */
    private suspend fun updateConsolidatedList(service: KartaliAccessibilityService, order: PaymentOrder) {
        // Asegurar que estamos dentro del chat "Compra y venta"
        service.clickByText("Compra y venta")
        delay(2000)

        val texts = service.getAllScreenTexts()
        val listMessage = texts.lastOrNull { it.contains("Pendientes por recibir:", ignoreCase = true) }

        if (listMessage != null && listMessage.trim().startsWith("Pendientes por recibir:", ignoreCase = true)) {
            val updatedList = "${listMessage.trim()}\n${order.toGroupListRow()}"
            service.setClipboard(updatedList)
            log("📝 Anexando fila: ${order.toGroupListRow()}")

            // Tocar barra de escribir mensaje
            if (!service.clickByText("Mensaje")) {
                service.clickAtPercent(0.45f, 0.94f)
            }
            delay(1500)
            if (!service.setTextIntoActiveField(updatedList)) {
                service.pasteIntoActiveField()
            }
            delay(2000)

            // Enviar mensaje
            service.clickAtPercent(0.90f, 0.93f)
            delay(2000)
            log("✅ Lista actualizada enviada al grupo 'Compra y venta'.")
        } else {
            log("⚠️ No se detectó mensaje 'Pendientes por recibir:' visible en pantalla.")
        }

        // Regresar a Home
        service.goHome()
    }
}
