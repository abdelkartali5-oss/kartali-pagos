package com.kartali.pagos

import android.content.Context
import android.content.Intent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

data class AgentOutcome(
    val success: Boolean,
    val detail: String
)

/**
 * Mini Agente de IA con visión de pantalla en tiempo real (Percepción ➔ Decisión ➔ Acción ➔ Verificación).
 * Nunca avanza a ciegas ni reporta éxito falso: lee los elementos visibles en pantalla en cada ciclo.
 */
class AutomationEngine(private val context: Context) {

    companion object {
        private const val BDV_PACKAGE = "com.bancodevenezuela.bdvdigital"
    }

    private fun log(msg: String) {
        AppLog.log(msg)
    }

    suspend fun executePayment(order: PaymentOrder): AgentOutcome = withContext(Dispatchers.Default) {
        val service = KartaliAccessibilityService.instance
            ?: return@withContext AgentOutcome(false, "El Servicio de Accesibilidad de Kartali Pagos está desactivado en Ajustes.")

        val storage = SecurityStorage(context)
        val password = storage.getPassword()
        if (password.isNullOrEmpty()) {
            return@withContext AgentOutcome(false, "No hay contraseña de BDV guardada en la cajita de la app Kartali Pagos.")
        }

        try {
            log("🧠 Agente iniciado para orden #${order.id}: ${order.dolares}$ ${order.metodo} -> ${order.cliente}")

            // Despertar pantalla si estaba apagada
            try {
                val wakeIntent = Intent(service, WakeActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                service.startActivity(wakeIntent)
            } catch (_: Exception) {}
            delay(1000)

            // 1. Lanzar Banco de Venezuela
            log("📲 Abriendo Banco de Venezuela...")
            if (!launchBdv(service)) {
                return@withContext AgentOutcome(false, "No se pudo abrir la aplicación BDV en el teléfono.")
            }

            delay(4000)

            var loginClicked = false
            var passwordFilled = false
            var dataPasted = false
            var payClicked = false
            var receiptVerified = false
            var blindStage = 0
            var lastScreenSummary = ""

            // =========================================================================
            // BUCLE DE PERCEPCIÓN Y RAZONAMIENTO DEL AGENTE (MÁX 26 CICLOS ~ 75 SEG)
            // =========================================================================
            for (step in 1..26) {
                val snap = service.captureScreen()
                lastScreenSummary = snap.summary()
                log("👁️ [Paso $step] Viendo [${snap.packageName}]: $lastScreenSummary")

                // Si BDV se cerró o salió al launcher a mitad del proceso, reabrirlo
                if (step > 2 && !snap.packageName.contains("bancodevenezuela", ignoreCase = true)
                    && !snap.packageName.contains("biometric", ignoreCase = true)
                    && !snap.packageName.contains("systemui", ignoreCase = true)
                    && !snap.packageName.contains("android", ignoreCase = true)
                ) {
                    log("⚠️ BDV no está en primer plano (${snap.packageName}). Reabriendo BDV...")
                    launchBdv(service)
                    delay(3500)
                    continue
                }

                // ---------------------------------------------------------------------
                // ESTADO 1: ¿YA LLEGAMOS AL COMPROBANTE DE OPERACIÓN? (ÉXITO REAL)
                // ---------------------------------------------------------------------
                if (snap.hasText("Comprobante de operación") ||
                    (snap.hasText("Operación:") && snap.hasText("Identificación:"))
                ) {
                    log("✅ ¡Comprobante de operación verificado con los ojos del Agente!")
                    receiptVerified = true
                    break
                }

                // ---------------------------------------------------------------------
                // ESTADO 2: ¿PANTALLA DE CONFIRMACIÓN FINAL DEL PAGO?
                // ---------------------------------------------------------------------
                if (payClicked && (snap.hasText("Confirmar") || snap.hasText("Confirmación"))) {
                    log("👆 Pantalla de confirmación detectada. Tocando 'Confirmar'...")
                    service.smartClick("Confirmar", 0.365f, 0.76f)
                    delay(4000)
                    continue
                }

                // ---------------------------------------------------------------------
                // ESTADO 3: ¿ESTAMOS DENTRO DEL FORMULARIO DE PAGO / TRANSFERENCIA?
                // (Se ve "Pegar datos", "Documento:", "Cuenta destino:" o "Instrumento destino:")
                // ---------------------------------------------------------------------
                if (snap.hasText("Pegar datos") || snap.hasText("Documento:") ||
                    snap.hasText("Cuenta destino:") || snap.hasText("Instrumento destino:")
                ) {
                    if (!dataPasted) {
                        val bdvClip = order.toBdvClipboardText()
                        service.setClipboard(bdvClip)
                        log("📋 Copiando datos del cliente y tocando 'Pegar datos'...")
                        delay(700)
                        service.smartClick("Pegar datos", 0.18f, 0.131f)
                        dataPasted = true
                        delay(3000)
                        continue
                    } else {
                        log("💳 Datos pegados. Tocando botón de envío ('Pagar' / 'Transferir')...")
                        if (order.tipo.equals("pagomovil", ignoreCase = true)) {
                            service.smartClick("Pagar", 0.365f, 0.762f)
                        } else {
                            if (!service.smartClick("Transferir", 0.365f, 0.567f)) {
                                service.smartClick("Pagar", 0.365f, 0.762f)
                            }
                        }
                        payClicked = true
                        delay(4500)
                        continue
                    }
                }

                // ---------------------------------------------------------------------
                // ESTADO 4: ¿ESTÁ ABIERTO EL SUBMENÚ DESPLEGABLE DE PAGOS O TRANSFERENCIAS?
                // ---------------------------------------------------------------------
                if (snap.hasText("PagomóvilBDV QR") || snap.hasText("Pagos compartidos")) {
                    log("👆 Submenú Pagos detectado. Tocando 'PagomóvilBDV'...")
                    service.smartClick("PagomóvilBDV", 0.40f, 0.66f)
                    delay(3000)
                    continue
                }

                if (snap.hasText("Cuentas propias") || snap.hasText("Cuentas de terceros") || snap.hasText("Cuentas otros bancos")) {
                    if (order.tipo.equals("terceros", ignoreCase = true)) {
                        log("👆 Submenú Transferencias detectado. Tocando 'Cuentas de terceros'...")
                        service.smartClick("Cuentas de terceros", 0.40f, 0.715f)
                    } else {
                        log("👆 Submenú Transferencias detectado. Tocando 'Cuentas otros bancos'...")
                        service.smartClick("Cuentas otros bancos", 0.40f, 0.79f)
                    }
                    delay(3000)
                    continue
                }

                // ---------------------------------------------------------------------
                // ESTADO 5: ¿ESTAMOS EN EL MENÚ PRINCIPAL DE BDV (SESIÓN YA INICIADA)?
                // ---------------------------------------------------------------------
                if (snap.hasText("Saldo Cuenta Corriente") || snap.hasText("Histórico de operaciones") ||
                    snap.hasText("Movimientos en línea") || (snap.hasText("Divisas") && snap.hasText("Servicios"))
                ) {
                    if (order.tipo.equals("pagomovil", ignoreCase = true)) {
                        log("📍 Menú principal detectado. Abriendo 'Pagos'...")
                        service.smartClick("Pagos", 0.415f, 0.91f)
                    } else {
                        log("📍 Menú principal detectado. Abriendo 'Transferencias'...")
                        service.smartClick("Transfer", 0.25f, 0.91f)
                    }
                    delay(3000)
                    continue
                }

                // ---------------------------------------------------------------------
                // ESTADO 6: ¿ESTÁ ABIERTA LA VENTANA DE CONTRASEÑA?
                // ("Contraseña:" o "Aceptar" + "Cancelar")
                // ---------------------------------------------------------------------
                if (snap.hasText("Contraseña") || (snap.hasText("Aceptar") && snap.hasText("Cancelar"))) {
                    if (!passwordFilled) {
                        log("🔐 Ventana de contraseña vista. Escribiendo clave en la casilla...")
                        service.smartFillText(password, "Contraseña", 0.45f, 0.485f)
                        passwordFilled = true
                        delay(2000)
                    }
                    log("👆 Tocando 'Aceptar' para iniciar sesión...")
                    service.smartClick("Aceptar", 0.372f, 0.573f, exact = true)
                    delay(4500)
                    continue
                }

                // ---------------------------------------------------------------------
                // ESTADO 7: ¿ESTÁ EN PANTALLA EL DIÁLOGO DE HUELLA DEL SISTEMA SAMSUNG?
                // ---------------------------------------------------------------------
                if (snap.packageName.contains("biometric", ignoreCase = true) ||
                    snap.hasText("huella") || snap.hasText("sensor") || snap.hasText("identidad")
                ) {
                    log("🔙 Ventana de huella detectada. Pulsando Atrás para cerrarla...")
                    service.pressBack()
                    delay(2000)
                    continue
                }

                // ---------------------------------------------------------------------
                // ESTADO 8: ¿ESTAMOS EN LA PANTALLA 2 DE LOGIN ("Ingresa con tu contraseña")?
                // ---------------------------------------------------------------------
                if (snap.hasText("Ingresa con tu contraseña") || snap.hasText("Pulsa para autenticarte") || snap.hasText("Iniciar sesión como")) {
                    log("👆 Pantalla de usuario vista. Tocando 'Ingresa con tu contraseña'...")
                    service.smartClick("Ingresa con tu contraseña", 0.50f, 0.595f)
                    delay(2500)
                    continue
                }

                // ---------------------------------------------------------------------
                // ESTADO 9: ¿ESTAMOS EN LA PORTADA INICIAL ("Iniciar sesión")?
                // ---------------------------------------------------------------------
                if (snap.hasText("Iniciar sesión") || snap.hasText("Quiero abrir una cuenta") || snap.hasText("Ver mis saldos")) {
                    log("👆 Portada de BDV vista. Tocando botón 'Iniciar sesión'...")
                    service.smartClick("Iniciar sesión", 0.50f, 0.495f)
                    loginClicked = true
                    delay(2800)
                    // Verificar si al tocar Iniciar sesión subió una huella invisible
                    val afterSnap = service.captureScreen()
                    if (!afterSnap.hasText("Ingresa con tu contraseña") && !afterSnap.hasText("Contraseña")) {
                        log("🔙 Cerrando posible prompt de huella con Atrás...")
                        service.pressBack()
                        delay(2000)
                    }
                    continue
                }

                // ---------------------------------------------------------------------
                // CASO ESPECIAL: Si la ventana actual tiene FLAG_SECURE y no expone nodos
                // ---------------------------------------------------------------------
                if (snap.allLabels.isEmpty()) {
                    blindStage++
                    log("👁️ Ventana protegida sin textos expuestos (etapa visual $blindStage)...")
                    when (blindStage) {
                        1 -> {
                            log("👆 Toque físico en 'Iniciar sesión' (50%, 49.5%)...")
                            service.clickAtPercent(0.50f, 0.495f)
                            delay(2500)
                        }
                        2 -> {
                            log("🔙 Pulsando Atrás por si se abrió la huella...")
                            service.pressBack()
                            delay(1800)
                            log("👆 Toque físico en 'Ingresa con tu contraseña' (50%, 59.5%)...")
                            service.clickAtPercent(0.50f, 0.595f)
                            delay(2500)
                        }
                        3 -> {
                            log("🔐 Enfocando casilla de clave (45%, 48.5%) y pegando clave...")
                            service.smartFillText(password, "Contraseña", 0.45f, 0.485f)
                            delay(2000)
                            log("👆 Toque físico en 'Aceptar' (37.2%, 57.3%)...")
                            service.clickAtPercent(0.372f, 0.573f)
                            delay(4500)
                        }
                        else -> delay(2500)
                    }
                    continue
                }

                delay(2500)
            }

            if (!receiptVerified) {
                return@withContext AgentOutcome(
                    false,
                    "El agente no vio 'Comprobante de operación' tras los intentos. Última pantalla vista: [$lastScreenSummary]"
                )
            }

            // =========================================================================
            // FASE WHATSAPP CON OJOS: COMPARTIR COMPROBANTE Y ACTUALIZAR LISTA
            // =========================================================================
            val waResult = executeWhatsAppAgent(service, order)
            return@withContext waResult

        } catch (e: Exception) {
            log("❌ Error en el Agente: ${e.message}")
            return@withContext AgentOutcome(false, "Excepción en el agente: ${e.message}")
        }
    }

    private fun launchBdv(service: KartaliAccessibilityService): Boolean {
        val pm = service.packageManager
        var launchIntent = pm.getLaunchIntentForPackage(BDV_PACKAGE)
        if (launchIntent == null) {
            val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
                addCategory(Intent.CATEGORY_LAUNCHER)
            }
            val apps = pm.queryIntentActivities(mainIntent, 0)
            val bdvApp = apps.firstOrNull {
                it.activityInfo.packageName.contains("bancodevenezuela", ignoreCase = true) ||
                it.activityInfo.packageName.contains("bdv", ignoreCase = true)
            }
            if (bdvApp != null) {
                launchIntent = pm.getLaunchIntentForPackage(bdvApp.activityInfo.packageName)
            }
        }
        return if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            service.startActivity(launchIntent)
            true
        } else false
    }

    /**
     * Agente visual para compartir el recibo en WhatsApp (Grupo + Cliente) y actualizar la lista.
     */
    private suspend fun executeWhatsAppAgent(
        service: KartaliAccessibilityService,
        order: PaymentOrder
    ): AgentOutcome {
        log("📤 Tocando icono Compartir en el comprobante...")
        service.smartClick("Compartir", 0.915f, 0.082f)
        delay(3000)

        val shareSnap = service.captureScreen()
        log("👁️ Menú compartir visto: ${shareSnap.summary()}")

        // Abrir selector de WhatsApp
        if (shareSnap.hasText("WhatsApp")) {
            service.smartClick("WhatsApp", 0.315f, 0.87f)
        } else {
            service.smartClick("Compra y venta", 0.15f, 0.72f)
        }
        delay(3000)

        // Seleccionar "Compra y venta" y el cliente si aparece en la lista
        val pickerSnap = service.captureScreen()
        log("👁️ Selector WhatsApp: ${pickerSnap.summary()}")
        if (pickerSnap.hasText("Compra y venta")) {
            service.smartClick("Compra y venta")
            delay(1800)
        }
        if (order.cliente.isNotBlank() && !order.cliente.equals("Cliente", ignoreCase = true) && pickerSnap.hasText(order.cliente)) {
            log("👤 Seleccionando también al cliente '${order.cliente}'...")
            service.smartClick(order.cliente)
            delay(1500)
        }

        // En el selector de WhatsApp de Samsung, al seleccionar un chat ya aparece abajo "Añade un comentario"
        val afterSelectSnap = service.captureScreen()
        if (afterSelectSnap.hasText("Añade un comentario")) {
            log("✍️ Escribiendo monto '${order.dolares}$' en el comentario...")
            service.smartFillText("${order.dolares}$", "Añade un comentario", 0.43f, 0.84f)
            delay(1800)
            log("🚀 Tocando botón verde Enviar...")
            service.clickAtPercent(0.914f, 0.92f)
            delay(3500)
        } else {
            // Si hay paso intermedio antes de la vista previa de imagen
            service.clickAtPercent(0.914f, 0.92f)
            delay(2500)
            log("✍️ Escribiendo monto '${order.dolares}$' en el comentario...")
            service.smartFillText("${order.dolares}$", "Añade un comentario", 0.43f, 0.84f)
            delay(1800)
            log("🚀 Tocando botón verde Enviar...")
            service.clickAtPercent(0.914f, 0.92f)
            delay(3500)
        }

        // Actualizar la lista consolidada "Pendientes por recibir:" en Compra y venta
        log("📋 Buscando última lista 'Pendientes por recibir:' en el grupo...")
        val chatSnap = service.captureScreen()
        if (chatSnap.hasText("Compra y venta") && !chatSnap.hasText("Pendientes por recibir:")) {
            service.smartClick("Compra y venta")
            delay(2500)
        }

        val groupTexts = service.getAllScreenTexts()
        val listMessage = groupTexts.lastOrNull { it.contains("Pendientes por recibir:", ignoreCase = true) }

        if (listMessage != null && listMessage.trim().startsWith("Pendientes por recibir:", ignoreCase = true)) {
            val updatedList = "${listMessage.trim()}\n${order.toGroupListRow()}"
            log("📝 Pegando lista actualizada con la fila: ${order.toGroupListRow()}")
            service.smartFillText(updatedList, "Mensaje", 0.45f, 0.94f)
            delay(2000)
            service.clickAtPercent(0.914f, 0.92f)
            delay(2000)
            log("✅ Lista 'Pendientes por recibir:' actualizada y enviada.")
        } else {
            log("ℹ️ Comprobante enviado. No se vio el mensaje 'Pendientes por recibir:' en la vista actual.")
        }

        return AgentOutcome(
            true,
            "Comprobante de operación verificado en BDV y enviado a WhatsApp (${order.dolares}$ ${order.metodo} ${order.cliente})."
        )
    }
}
