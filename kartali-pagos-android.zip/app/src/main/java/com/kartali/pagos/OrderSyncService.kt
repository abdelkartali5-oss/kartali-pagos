package com.kartali.pagos

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.util.Log
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Servicio en primer plano que conecta al Mini Agente Kartali con Google Apps Script / Telegram.
 */
class OrderSyncService : Service() {

    companion object {
        private const val TAG = "KartaliSync"
        private const val CHANNEL_ID = "kartali_terminal_channel"
        private const val NOTIFICATION_ID = 1001

        private const val GAS_ENDPOINT = "https://script.google.com/macros/s/AKfycbzbJ_tnGoBHhvUENI7UUvFWpzWS4vs5nj4X4UCemcJSgj6ZRQLosfSUeafQOTeqxY25/exec"

        fun start(context: Context) {
            val intent = Intent(context, OrderSyncService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }
    }

    private val serviceScope = CoroutineScope(Dispatchers.IO + Job())
    private var isPolling = false
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        val notification = buildNotification("🟢 Mini Agente Kartali Activo", "Monitoreando órdenes desde Telegram...")
        startForeground(NOTIFICATION_ID, notification)

        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "kartali:synclock")
        wakeLock?.acquire(60 * 60 * 1000L)

        startPollingLoop()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        super.onDestroy()
        isPolling = false
        serviceScope.cancel()
        wakeLock?.release()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun startPollingLoop() {
        isPolling = true
        serviceScope.launch {
            val engine = AutomationEngine(applicationContext)

            while (isPolling) {
                try {
                    val orderJson = fetchPendingOrder()
                    if (orderJson != null) {
                        val order = PaymentOrder.fromJson(orderJson)
                        AppLog.log("⚡ Nueva orden recibida de Telegram: #${order.id}")

                        wakeUpScreen()
                        val outcome = engine.executePayment(order)
                        reportOrderCompleted(order.id, outcome.success, outcome.detail)
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Error en sincronización: ${e.message}")
                }
                delay(2500)
            }
        }
    }

    private fun fetchPendingOrder(): JSONObject? {
        val url = URL("$GAS_ENDPOINT?action=get_pending")
        val conn = url.openConnection() as HttpURLConnection
        conn.requestMethod = "GET"
        conn.connectTimeout = 7000
        conn.readTimeout = 7000

        return try {
            if (conn.responseCode == 200) {
                val response = conn.inputStream.bufferedReader().use { it.readText() }
                val json = JSONObject(response)
                if (json.optBoolean("has_order", false)) {
                    json.getJSONObject("order")
                } else null
            } else null
        } finally {
            conn.disconnect()
        }
    }

    private fun reportOrderCompleted(orderId: String, success: Boolean, detail: String) {
        val encodedDetail = URLEncoder.encode(detail, "UTF-8")
        val url = URL("$GAS_ENDPOINT?action=complete&id=$orderId&success=$success&detail=$encodedDetail")
        val conn = url.openConnection() as HttpURLConnection
        conn.requestMethod = "GET"
        try {
            conn.responseCode
        } finally {
            conn.disconnect()
        }
    }

    @Suppress("DEPRECATION")
    private fun wakeUpScreen() {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        val screenLock = pm.newWakeLock(
            PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP,
            "kartali:screenturnon"
        )
        screenLock.acquire(5000)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Terminal Kartali Pagos",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(title: String, text: String): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(text)
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setOngoing(true)
            .build()
    }
}
