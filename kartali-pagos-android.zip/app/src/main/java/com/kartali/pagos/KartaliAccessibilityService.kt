package com.kartali.pagos

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.util.DisplayMetrics
import android.util.Log
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.text.Normalizer

/**
 * Representa un elemento visible en la pantalla leído por los "ojos" del Agente.
 */
data class UiElement(
    val text: String,
    val contentDesc: String,
    val hint: String,
    val className: String,
    val viewId: String,
    val bounds: Rect,
    val isClickable: Boolean,
    val isEditable: Boolean,
    val isPassword: Boolean,
    val node: AccessibilityNodeInfo
) {
    val label: String
        get() = listOf(text, contentDesc, hint).firstOrNull { it.isNotBlank() } ?: ""
}

/**
 * Fotografía completa de lo que hay en pantalla en un instante dado.
 */
data class ScreenSnapshot(
    val packageName: String,
    val elements: List<UiElement>
) {
    val allLabels: List<String>
        get() = elements.mapNotNull { it.label.takeIf { s -> s.isNotBlank() } }

    fun hasText(query: String): Boolean {
        val q = KartaliAccessibilityService.normalize(query)
        return elements.any {
            KartaliAccessibilityService.normalize(it.text).contains(q) ||
            KartaliAccessibilityService.normalize(it.contentDesc).contains(q) ||
            KartaliAccessibilityService.normalize(it.hint).contains(q)
        }
    }

    fun findElement(query: String, exact: Boolean = false): UiElement? {
        val q = KartaliAccessibilityService.normalize(query)
        val candidates = elements.filter { el ->
            val t = KartaliAccessibilityService.normalize(el.text)
            val d = KartaliAccessibilityService.normalize(el.contentDesc)
            val h = KartaliAccessibilityService.normalize(el.hint)
            if (exact) (t == q || d == q || h == q)
            else (t.contains(q) || d.contains(q) || h.contains(q))
        }
        // Preferir elementos con coordenadas válidas en pantalla
        return candidates.firstOrNull { it.bounds.width() > 5 && it.bounds.height() > 5 }
            ?: candidates.firstOrNull()
    }

    fun summary(): String {
        val preview = allLabels.map { it.replace("\n", " ").trim() }
            .filter { it.isNotEmpty() }
            .distinct()
            .take(8)
            .joinToString(" | ")
        return if (preview.isEmpty()) "(sin textos accesibles)" else preview
    }
}

/**
 * Servicio de Accesibilidad oficial de Kartali Pagos con visión del árbol UI y gestos físicos.
 */
class KartaliAccessibilityService : AccessibilityService() {

    companion object {
        private const val TAG = "KartaliService"
        var instance: KartaliAccessibilityService? = null
            private set

        val isRunning: Boolean get() = instance != null

        fun normalize(input: String?): String {
            if (input.isNullOrEmpty()) return ""
            val temp = Normalizer.normalize(input, Normalizer.Form.NFD)
            return temp.replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")
                .lowercase()
                .trim()
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        AppLog.log("🟢 Ojos y manos del Agente Kartali conectados.")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {
        Log.w(TAG, "⚠️ Servicio interrumpido.")
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
    }

    // =========================================================================
    // DIMENSIONES FÍSICAS REALES DE LA PANTALLA SAMSUNG
    // =========================================================================

    @Suppress("DEPRECATION")
    fun getRealScreenSize(): Pair<Int, Int> {
        return try {
            val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                val bounds = wm.currentWindowMetrics.bounds
                Pair(bounds.width(), bounds.height())
            } else {
                val dm = DisplayMetrics()
                wm.defaultDisplay.getRealMetrics(dm)
                Pair(dm.widthPixels, dm.heightPixels)
            }
        } catch (e: Exception) {
            val dm = resources.displayMetrics
            Pair(dm.widthPixels, dm.heightPixels)
        }
    }

    // =========================================================================
    // LOS "OJOS" DEL AGENTE: ESCÁNER COMPLETO DE LA PANTALLA EN VIVO
    // =========================================================================

    fun captureScreen(): ScreenSnapshot {
        val elements = mutableListOf<UiElement>()
        var activePkg = ""

        val roots = mutableListOf<AccessibilityNodeInfo>()
        try {
            rootInActiveWindow?.let {
                activePkg = it.packageName?.toString() ?: ""
                roots.add(it)
            }
        } catch (_: Exception) {}

        try {
            val winList = windows
            if (!winList.isNullOrEmpty()) {
                for (w in winList) {
                    val r = w.root ?: continue
                    if (activePkg.isEmpty()) activePkg = r.packageName?.toString() ?: ""
                    if (roots.none { it == r }) roots.add(r)
                }
            }
        } catch (_: Exception) {}

        fun traverse(node: AccessibilityNodeInfo?, depth: Int) {
            if (node == null || depth > 40) return
            val rect = Rect()
            try {
                node.getBoundsInScreen(rect)
            } catch (_: Exception) {}

            val txt = node.text?.toString() ?: ""
            val desc = node.contentDescription?.toString() ?: ""
            val hint = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                node.hintText?.toString() ?: ""
            } else ""
            val cls = node.className?.toString() ?: ""
            val vid = node.viewIdResourceName ?: ""

            if (txt.isNotBlank() || desc.isNotBlank() || hint.isNotBlank() || node.isEditable || node.isPassword || node.isClickable) {
                elements.add(
                    UiElement(
                        text = txt,
                        contentDesc = desc,
                        hint = hint,
                        className = cls,
                        viewId = vid,
                        bounds = rect,
                        isClickable = node.isClickable,
                        isEditable = node.isEditable || cls.contains("EditText", ignoreCase = true),
                        isPassword = node.isPassword,
                        node = node
                    )
                )
            }

            val count = try { node.childCount } catch (_: Exception) { 0 }
            for (i in 0 until count) {
                val child = try { node.getChild(i) } catch (_: Exception) { null }
                traverse(child, depth + 1)
            }
        }

        for (r in roots) {
            traverse(r, 0)
        }

        return ScreenSnapshot(activePkg, elements)
    }

    // =========================================================================
    // LAS "MANOS" DEL AGENTE: TOQUES FÍSICOS + ACCIONES DE NAVEGACIÓN
    // =========================================================================

    /**
     * Toque físico real en pantalla con trazo válido para Samsung One UI.
     */
    suspend fun clickAt(x: Float, y: Float, durationMs: Long = 120): Boolean = withContext(Dispatchers.Main) {
        val safeX = x.coerceAtLeast(1f)
        val safeY = y.coerceAtLeast(1f)
        val path = Path().apply {
            moveTo(safeX, safeY)
            lineTo(safeX + 1f, safeY + 1f)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0, durationMs)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()

        val deferred = CompletableDeferred<Boolean>()
        val dispatched = dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                deferred.complete(true)
            }
            override fun onCancelled(gestureDescription: GestureDescription?) {
                deferred.complete(false)
            }
        }, null)

        if (!dispatched) false else deferred.await()
    }

    suspend fun clickAtPercent(xPercent: Float, yPercent: Float, durationMs: Long = 120): Boolean {
        val (w, h) = getRealScreenSize()
        val pxX = w * xPercent
        val pxY = h * yPercent
        return clickAt(pxX, pxY, durationMs)
    }

    /**
     * Busca el elemento con sus ojos; si lo ve, toca sus coordenadas exactas Y lanza ACTION_CLICK.
     * Si no lo ve en el árbol (ej. WebView bloqueado), usa la coordenada de respaldo medida.
     */
    suspend fun smartClick(
        query: String,
        fallbackXPercent: Float? = null,
        fallbackYPercent: Float? = null,
        exact: Boolean = false
    ): Boolean {
        val snap = captureScreen()
        val el = snap.findElement(query, exact)
        if (el != null) {
            // 1. Intentar acción de accesibilidad en el nodo o su padre clickeable
            var target: AccessibilityNodeInfo? = el.node
            var depth = 0
            while (target != null && !target.isClickable && depth < 5) {
                target = target.parent
                depth++
            }
            try {
                target?.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                el.node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            } catch (_: Exception) {}

            // 2. Además, tocar físicamente las coordenadas del elemento si tiene rectángulo válido
            if (el.bounds.width() > 5 && el.bounds.height() > 5) {
                val cx = el.bounds.exactCenterX()
                val cy = el.bounds.exactCenterY()
                clickAt(cx, cy, 120)
                return true
            }
            return true
        }

        // 3. Si el WebView no expuso el nodo, usar coordenada física de respaldo
        if (fallbackXPercent != null && fallbackYPercent != null) {
            return clickAtPercent(fallbackXPercent, fallbackYPercent, 120)
        }
        return false
    }

    /**
     * Rellena la contraseña o texto en una casilla enfocándola primero y probando
     * inyección directa + pegado nativo de portapapeles.
     */
    suspend fun smartFillText(
        textToFill: String,
        fieldHintQuery: String? = null,
        tapXPercent: Float = 0.45f,
        tapYPercent: Float = 0.485f
    ): Boolean {
        setClipboard(textToFill)
        delay(300)

        val snap = captureScreen()
        val editElement = (if (fieldHintQuery != null) snap.findElement(fieldHintQuery) else null)
            ?: snap.elements.firstOrNull { it.isPassword || it.isEditable }

        if (editElement != null && editElement.bounds.width() > 5) {
            clickAt(editElement.bounds.exactCenterX(), editElement.bounds.exactCenterY(), 120)
            delay(800)
            try {
                editElement.node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
                editElement.node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                val args = Bundle().apply {
                    putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, textToFill)
                }
                if (editElement.node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) {
                    return true
                }
                if (editElement.node.performAction(AccessibilityNodeInfo.ACTION_PASTE)) {
                    return true
                }
            } catch (_: Exception) {}
        } else {
            // Tocar físicamente la casilla por coordenada medida
            clickAtPercent(tapXPercent, tapYPercent, 120)
            delay(1000)
        }

        // Intentar sobre el nodo que haya ganado foco de entrada
        if (setTextIntoActiveField(textToFill)) return true
        if (pasteIntoActiveField()) return true

        // Último recurso: pulsación larga en la casilla para abrir el botón "Pegar" de Android
        clickAtPercent(tapXPercent, tapYPercent, 750)
        delay(900)
        smartClick("Pegar")
        return true
    }

    fun pressBack(): Boolean = performGlobalAction(GLOBAL_ACTION_BACK)

    fun goHome(): Boolean = performGlobalAction(GLOBAL_ACTION_HOME)

    fun setTextIntoActiveField(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    fun pasteIntoActiveField(): Boolean {
        val root = rootInActiveWindow ?: return false
        val focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        return focused.performAction(AccessibilityNodeInfo.ACTION_PASTE)
    }

    fun setClipboard(text: String) = MainScopeRunner.runOnMain {
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText("Kartali", text)
        clipboard.setPrimaryClip(clip)
    }

    fun getAllScreenTexts(): List<String> = captureScreen().allLabels
}

object MainScopeRunner {
    private val handler = android.os.Handler(android.os.Looper.getMainLooper())
    fun runOnMain(block: () -> Unit) {
        if (android.os.Looper.myLooper() == android.os.Looper.getMainLooper()) {
            block()
        } else {
            handler.post(block)
        }
    }
}
