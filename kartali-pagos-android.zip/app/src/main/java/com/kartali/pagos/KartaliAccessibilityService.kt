package com.kartali.pagos

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.util.DisplayMetrics
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Servicio de Accesibilidad oficial de Kartali Pagos.
 * Maneja el control táctil por hardware (gestures) y la navegación de BDV y WhatsApp.
 */
class KartaliAccessibilityService : AccessibilityService() {

    companion object {
        private const val TAG = "KartaliService"
        var instance: KartaliAccessibilityService? = null
            private set

        val isRunning: Boolean get() = instance != null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Log.i(TAG, "🟢 KartaliAccessibilityService conectado y listo.")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Monitoreo de eventos de ventana si se requiere reactividad en tiempo real
    }

    override fun onInterrupt() {
        Log.w(TAG, "⚠️ KartaliAccessibilityService interrumpido.")
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
        Log.i(TAG, "🔴 KartaliAccessibilityService detenido.")
    }

    // =========================================================================
    // ACCIONES TÁCTILES Y DE GESTOS (Indetectables e inmunes a FLAG_SECURE)
    // =========================================================================

    /**
     * Realiza un clic físico simulado en coordenadas exactas de pantalla.
     */
    suspend fun clickAt(x: Float, y: Float, durationMs: Long = 100): Boolean = withContext(Dispatchers.Main) {
        val path = Path().apply {
            moveTo(x, y)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0, durationMs)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()

        val deferred = CompletableDeferred<Boolean>()
        val dispatched = dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                deferred.complete(true)
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                deferred.complete(false)
            }
        }, null)

        if (!dispatched) false else deferred.await()
    }

    /**
     * Realiza un clic utilizando porcentajes de pantalla (0.0 a 1.0).
     */
    suspend fun clickAtPercent(xPercent: Float, yPercent: Float, durationMs: Long = 100): Boolean {
        val dm = resources.displayMetrics
        val pxX = dm.widthPixels * xPercent
        val pxY = dm.heightPixels * yPercent
        return clickAt(pxX, pxY, durationMs)
    }

    /**
     * Clic largo simulado para copiar mensajes en WhatsApp.
     */
    suspend fun longClickAt(x: Float, y: Float, durationMs: Long = 800): Boolean = withContext(Dispatchers.Main) {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0, durationMs)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()

        val deferred = CompletableDeferred<Boolean>()
        val dispatched = dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                deferred.complete(true)
            }
            override fun onCancelled(gestureDescription: GestureDescription?) {
                deferred.complete(false)
            }
        }, null)

        if (!dispatched) false else deferred.await()
    }

    // =========================================================================
    // ACCIONES DE NAVEGACIÓN Y TEXTO POR ACCESIBILIDAD
    // =========================================================================

    /**
     * Presiona el botón Atrás nativo de Android (cierra huella o diálogos).
     */
    fun pressBack(): Boolean {
        return performGlobalAction(GLOBAL_ACTION_BACK)
    }

    /**
     * Presiona el botón Inicio (Home) de Android.
     */
    fun goHome(): Boolean {
        return performGlobalAction(GLOBAL_ACTION_HOME)
    }

    /**
     * Busca un elemento en pantalla que contenga el texto y le hace clic.
     */
    fun clickByText(text: String, exact: Boolean = false): Boolean {
        val root = rootInActiveWindow ?: return false
        val nodes = root.findAccessibilityNodeInfosByText(text)
        if (nodes.isNullOrEmpty()) return false

        for (node in nodes) {
            val nodeText = node.text?.toString() ?: ""
            val matches = if (exact) nodeText.equals(text, ignoreCase = true) else nodeText.contains(text, ignoreCase = true)
            if (matches) {
                // Si el nodo no es clickeable, buscar en sus ancestros
                var target: AccessibilityNodeInfo? = node
                while (target != null && !target.isClickable) {
                    target = target.parent
                }
                val clicked = target?.performAction(AccessibilityNodeInfo.ACTION_CLICK) ?: false
                if (clicked) return true
            }
        }
        return false
    }

    /**
     * Busca un nodo editable y le inyecta texto directamente.
     */
    fun setTextIntoActiveField(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        if (focused != null) {
            val args = Bundle().apply {
                putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
            }
            return focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        }
        return false
    }

    /**
     * Ejecuta la acción nativa de pegar (ACTION_PASTE) en el campo enfocado.
     */
    fun pasteIntoActiveField(): Boolean {
        val root = rootInActiveWindow ?: return false
        val focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        return focused?.performAction(AccessibilityNodeInfo.ACTION_PASTE) ?: false
    }

    /**
     * Llena el portapapeles del sistema con un texto específico.
     */
    fun setClipboard(text: String) {
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText("Kartali", text)
        clipboard.setPrimaryClip(clip)
    }

    /**
     * Lee el contenido actual del portapapeles.
     */
    fun getClipboard(): String {
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        return clipboard.primaryClip?.getItemAt(0)?.text?.toString() ?: ""
    }

    /**
     * Busca todos los textos de la pantalla actual para leer la lista de WhatsApp.
     */
    fun getAllScreenTexts(): List<String> {
        val root = rootInActiveWindow ?: return emptyList()
        val results = mutableListOf<String>()

        fun traverse(node: AccessibilityNodeInfo?) {
            if (node == null) return
            node.text?.let { results.add(it.toString()) }
            for (i in 0 until node.childCount) {
                traverse(node.getChild(i))
            }
        }
        traverse(root)
        return results
    }
}
