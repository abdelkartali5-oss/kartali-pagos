package com.kartali.pagos

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.textfield.TextInputEditText

class MainActivity : AppCompatActivity(), AutomationEngine.Logger {

    private lateinit var tvStatusBadge: TextView
    private lateinit var tvAccessibilityStatus: TextView
    private lateinit var btnEnableAccessibility: Button
    private lateinit var etBdvPassword: TextInputEditText
    private lateinit var btnSavePassword: Button
    private lateinit var tvLogs: TextView
    private lateinit var svLogs: ScrollView
    private lateinit var btnClearLogs: TextView

    private lateinit var securityStorage: SecurityStorage

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        securityStorage = SecurityStorage(this)

        initViews()
        setupListeners()
        updateStatus()

        // Iniciar servicio en segundo plano para escuchar órdenes
        OrderSyncService.start(this)
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
    }

    private fun initViews() {
        tvStatusBadge = findViewById(R.id.tvStatusBadge)
        tvAccessibilityStatus = findViewById(R.id.tvAccessibilityStatus)
        btnEnableAccessibility = findViewById(R.id.btnEnableAccessibility)
        etBdvPassword = findViewById(R.id.etBdvPassword)
        btnSavePassword = findViewById(R.id.btnSavePassword)
        tvLogs = findViewById(R.id.tvLogs)
        svLogs = findViewById(R.id.svLogs)
        btnClearLogs = findViewById(R.id.btnClearLogs)

        // Si ya hay contraseña guardada, mostrar asteriscos
        if (securityStorage.hasPassword()) {
            etBdvPassword.setText("••••••••••••")
        }
    }

    private fun setupListeners() {
        btnEnableAccessibility.setOnClickListener {
            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
            startActivity(intent)
        }

        btnSavePassword.setOnClickListener {
            val pwd = etBdvPassword.text?.toString()?.trim() ?: ""
            if (pwd.isNotEmpty() && !pwd.startsWith("•")) {
                val saved = securityStorage.savePassword(pwd)
                if (saved) {
                    Toast.makeText(this, "✅ Contraseña guardada de forma segura", Toast.LENGTH_SHORT).show()
                    log("🔐 Contraseña de BDV actualizada y cifrada en el dispositivo.")
                } else {
                    Toast.makeText(this, "❌ Error al cifrar contraseña", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Introduce una contraseña válida", Toast.LENGTH_SHORT).show()
            }
        }

        btnClearLogs.setOnClickListener {
            tvLogs.text = ""
        }
    }

    private fun updateStatus() {
        val isServiceActive = KartaliAccessibilityService.isRunning

        if (isServiceActive) {
            tvAccessibilityStatus.text = "🟢 Servicio Activo y Listo"
            tvAccessibilityStatus.setTextColor(getColor(R.color.status_green))
            tvStatusBadge.text = "🟢 Terminal Activo"
            tvStatusBadge.setTextColor(getColor(R.color.status_green))
            btnEnableAccessibility.isEnabled = false
            btnEnableAccessibility.text = "✅ Accesibilidad Habilitada"
        } else {
            tvAccessibilityStatus.text = "🔴 Servicio Inactivo (Requiere activación)"
            tvAccessibilityStatus.setTextColor(getColor(R.color.status_red))
            tvStatusBadge.text = "🔴 Inactivo"
            tvStatusBadge.setTextColor(getColor(R.color.status_red))
            btnEnableAccessibility.isEnabled = true
            btnEnableAccessibility.text = "⚙️ Activar en Ajustes"
        }
    }

    override fun log(message: String) {
        runOnUiThread {
            val time = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date())
            tvLogs.append("[$time] $message\n")
            svLogs.post { svLogs.fullScroll(ScrollView.FOCUS_DOWN) }
        }
    }
}
